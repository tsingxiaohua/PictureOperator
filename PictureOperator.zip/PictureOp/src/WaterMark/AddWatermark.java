package WaterMark;

import java.awt.image.BufferedImage;  
import java.awt.image.WritableRaster;  


import WaterMark.ImageUtil;
import WaterMark.MathTool;


public class AddWatermark {  
	private static final int d = 5;  
	public int run(String filepath1,String filepath2,String filepath3) {  
		BufferedImage oImage = ImageUtil.getImage(filepath1);  
		BufferedImage wImage = ImageUtil.getImage(filepath2);  
		int type = oImage.getType();  
		WritableRaster oRaster = oImage.getRaster();  
		WritableRaster wRaster = wImage.getRaster();  
		int oWidth = oRaster.getWidth();  
		int oHeight = oRaster.getHeight();  
		int wWidth = wRaster.getWidth();  
		int wHeight = wRaster.getHeight();  
		int[] oPixels = new int[3 * oWidth * oHeight];  
		int[] wPixels = new int[wWidth * wHeight];  
		//System.out.println(oWidth+"    "+oHeight+"    "+oPixels);
		if(oWidth>=16*wWidth&&oHeight>=16*wHeight&&wWidth>=32&&wHeight>=32){
			oRaster.getPixels(0, 0, oWidth, oHeight, oPixels);  
			wRaster.getPixels(0, 0, wWidth, wHeight, wPixels);  
			int[][][] RGBPixels = ImageUtil.getRGBArrayToMatrix(oPixels, oWidth,  
					oHeight);  
			// �õ�RGBͼ�����������ʾ  
			double[][] rPixels = MathTool.intToDoubleMatrix(RGBPixels[2]);  
			int[][] wDMatrix = ImageUtil.arrayToMatrix(wPixels, wWidth, wHeight);  
			double[][] result = rPixels;  
			// Ƕ���㷨  
			for (int i = 0; i < wWidth; i++) {  
				for (int j = 0; j < wHeight; j++) {  
					double[][] blk = new double[8][8];  
					// ��ԭʼͼ��8 * 8 �ֿ�  
					for (int m = 0; m < 8; m++) {  
						for (int n = 0; n < 8; n++) {  
							blk[m][n] = rPixels[8 * i + m][8 * j + n];  
						}  
					}  
					double[][] dBlk = FDct.fDctTransform(blk);  
					if (wDMatrix[i][j] == 0) {  
						dBlk[3][3] = dBlk[3][3] - d;  
						dBlk[3][4] = dBlk[3][4] - d;  
						dBlk[3][5] = dBlk[3][5] - d;  
						dBlk[4][3] = dBlk[4][3] - d;  
						dBlk[5][3] = dBlk[5][3] - d;  
					} else {  
						dBlk[3][3] = dBlk[3][3] + d;  
						dBlk[3][4] = dBlk[3][4] + d;  
						dBlk[3][5] = dBlk[3][5] + d;  
						dBlk[4][3] = dBlk[4][3] + d;  
						dBlk[5][3] = dBlk[5][3] + d;  
					}  
					blk = IFDct.iFDctTransform(dBlk);  
					for (int m = 0; m < 8; m++) {  
						for (int n = 0; n < 8; n++) {  
							result[8 * i + m][8 * j + n] = blk[m][n];  
						}  
					}  
				}  
			}  
			double[][][] temp = new double[3][oWidth][oHeight];  
			temp[0] = MathTool.intToDoubleMatrix(RGBPixels[0]);  
			temp[1] = MathTool.intToDoubleMatrix(RGBPixels[1]);  
			temp[2] = result;  
			double[] rgbResult = ImageUtil.getRGBMatrixToArray(temp);  
			// ��BufferedImage����д�����  
			ImageUtil.setImage(rgbResult, oWidth, oHeight, filepath3,  
					"bmp", type); 
		}
		else if(wHeight<32||wWidth<32){
			return -1;
		}
		else if(oWidth<16*wWidth||oHeight<16*wHeight){
			return -2;
		}
		return 0;
	}
}  