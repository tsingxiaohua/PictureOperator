package WaterMark;

import java.awt.image.BufferedImage;  
import java.awt.image.WritableRaster;  

import WaterMark.ImageUtil;
import WaterMark.MathTool;


public class ExtractWatermark {   
	public void run(String filepath1,String filepath2,String filepath3,int wWidth, int wHeight) {  
		// mImage��Ƕ��ˮӡ���ͼ��  
		BufferedImage mImage = ImageUtil.getImage(filepath1);  
		// ԭʼͼ��  
		BufferedImage oImage = ImageUtil.getImage(filepath2);  
		WritableRaster oRaster = oImage.getRaster();  
		WritableRaster mRaster = mImage.getRaster();  
		int oWidth = oRaster.getWidth();  
		int oHeight = oRaster.getHeight();  
		int[] oPixels = new int[3 * oWidth * oHeight];  
		int[] mPixels = new int[3 * oWidth * oHeight];
		oRaster.getPixels(0, 0, oWidth, oHeight, oPixels);  
		mRaster.getPixels(0, 0, oWidth, oHeight, mPixels);  
		// ��rgbͼ���������mRgbPixels[0]��ʾb�����  
		int[][][] mRgbPixels = ImageUtil.getRGBArrayToMatrix(mPixels, oWidth,  
				oHeight);  
		int[][][] oRgbPixels = ImageUtil.getRGBArrayToMatrix(oPixels, oWidth,  
				oHeight);  
		double[][] oDPixels = MathTool.intToDoubleMatrix(mRgbPixels[2]);  
		double[][] mDPixels = MathTool.intToDoubleMatrix(oRgbPixels[2]);  
		double[][] result = new double[wWidth][wHeight];  
		for (int i = 0; i < wWidth; i++) {  
			for (int j = 0; j < wHeight; j++) {  
				double[][] oBlk = new double[8][8];  
				double[][] mBlk = new double[8][8];  
				int d = 0;  
				int f = 0;  
				for (int m = 0; m < 8; m++) {  
					for (int n = 0; n < 8; n++) {  
						oBlk[m][n] = oDPixels[8 * i + m][8 * j + n];  
						mBlk[m][n] = mDPixels[8 * i + m][8 * j + n];  
					}  
				}  
				double[][] dOBlk = FDct.fDctTransform(oBlk);  
				double[][] dMBlk = FDct.fDctTransform(mBlk);  
				if (dOBlk[3][3] > dMBlk[3][3]) {  
					d++;  
				} else {  
					f++;  
				}  
				if (dOBlk[3][4] > dMBlk[3][4]) {  
					d++;  
				} else {  
					f++;  
				}  
				if (dOBlk[3][5] > dMBlk[3][5]) {  
					d++;  
				} else {  
					f++;  
				}  
				if (dOBlk[4][3] > dMBlk[4][3]) {  
					d++;  
				} else {  
					f++;  
				}  
				if (dOBlk[5][3] > dMBlk[5][3]) {  
					d++;  
				} else {  
					f++;  
				}  
				if (d < f) {  
					result[i][j] = 0;  
				} else {  
					result[i][j] = 1;  
				}  
			}  
		}  
		double[] outResult = ImageUtil.matrixToArray(result);  
		// ��Ƕ��ˮӡ�Ľ��д��BufferedImage����  
		ImageUtil.setImage(outResult, wWidth, wHeight, filepath3, "bmp",  
				BufferedImage.TYPE_BYTE_BINARY);  
	}  

}  