package MyInterface;

import java.awt.BorderLayout;
import java.awt.Button;
import java.awt.Color;
import java.awt.Component;
import java.awt.Frame;
import java.awt.Image;
import java.awt.Label;
import java.awt.Panel;
import java.awt.TextField;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.JPanel;

import org.omg.CORBA.PUBLIC_MEMBER;

import MainProcess.ImageProcessOne;
import MainProcess.ImageProcessTwo;
import WaterMark.AddWatermark;
import WaterMark.ExtractWatermark;

import java.awt.Font;
import java.awt.SystemColor;

import javax.swing.SwingConstants;
import javax.swing.UIManager;

public class Interface {
	private static JTextField textField_2;
	private static JTextField textField_3;
	private static JTextField textField_4;
	private static JTextField textField_5;
	private static JTextField textField_6;
	private static JTextField textField_7;
	private static JTextField textField_8;
	public static Panel mainpanel=new Panel();
	public static JPanel panel=new JPanel();
	public static String filepath=null;//ԭͼƬ·��
	public static String watermarkpath=null;//ˮӡͼƬ·��
	public static String encpath=null;//������ͼƬ·��
	public static String filepath1="D://Done/��ת.jpg";
	public static String filepath2="D://Done/����.jpg";
	public static String filepath3="D://Done/������.jpg";
	public static String filepath4="D://Done/���Ĳü�.jpg";
	public static String filepath5="D://Done/���ֲü�.jpg";
	public static String filepath6="D://Done/����ü�.jpg";
	private static JTextField textField_1;
	private static JTextField textField_9;
	private static JTextField textField_10;


	public static boolean isNumeric(String str){ 
		Pattern pattern = Pattern.compile("[0-9]*"); 
		return pattern.matcher(str).matches();    
	}

	public static boolean isAllNumeric(String str){ 
		Pattern pattern = Pattern.compile("^[-\\+]?[\\d]*$"); 
		Matcher isNum = pattern.matcher(str);
		if( !isNum.matches() ){
			return false; 
		} 
		return true; 
	}

	public static void main(String agrs[]) throws IOException{
		Frame main= new Frame("\u56FE\u7247\u64CD\u4F5C\u5668");
		main.addWindowListener(new WindowAdapter() {
			public void windowClosing(WindowEvent we) {
				System.exit(0);
			}
		});

		Image icon =Toolkit.getDefaultToolkit().getImage("G://�����//����//���膴����//PictureOp//img//����1.png");
		main.setIconImage(icon);
		panel.setForeground(Color.WHITE);
		panel.setLayout(new BorderLayout(0, 0));

		final JLabel label_7 = new JLabel("");
		label_7.setForeground(new Color(250, 240, 230));
		label_7.setHorizontalAlignment(SwingConstants.CENTER);
		panel.add(label_7, BorderLayout.CENTER);




		panel.setBounds(20, 22, 730, 730);
		mainpanel.setBackground(Color.GRAY);
		mainpanel.add(panel);
		Button button_1 = new Button("\u9009\u62E9\u6587\u4EF6");
		button_1.setFont(new Font("Dialog", Font.BOLD, 14));
		button_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser jFileChooser = new JFileChooser();
				File file = null;
				int retureval = jFileChooser.showOpenDialog(null);
				if(retureval == JFileChooser.APPROVE_OPTION){
					file = jFileChooser.getSelectedFile();
					filepath = file.getAbsolutePath();
					textField_1.setText(filepath);
					textField_2.setText(null);
					textField_3.setText(null);
					textField_4.setText(null);
					textField_5.setText(null);
					textField_6.setText(null);
					textField_7.setText(null);
					textField_8.setText(null);
					try {
						label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath))));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ԭͼƬѡ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				}
				else if(retureval==JFileChooser.CANCEL_OPTION){
					return;
				}
			}
		});
		button_1.setActionCommand("\u65CB\u8F6C");
		button_1.setBounds(975, 91, 71, 23);
		mainpanel.add(button_1);
		mainpanel.setLayout(null);


		main.add(mainpanel);

		main.setResizable(false);
		panel.setBackground(Color.DARK_GRAY);







		Button button_2=new Button("\u65CB\u8F6C");
		button_2.setFont(new Font("Dialog", Font.BOLD, 14));
		button_2.setActionCommand("\u65CB\u8F6C");
		button_2.setBounds(975, 149, 71, 23);
		button_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {    //��ת
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_2.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�ǶȲ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(!isAllNumeric(textField_2.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�Ƕȱ�����������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				

				String str=textField_2.getText();
				int angel=Integer.parseInt(str);
				if(angel>32768||angel<-32767){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�Ƕ�ֵ���Ϸ���", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				File donefile = new File("D:\\Done");
				if(!donefile.isFile()){
					donefile.mkdirs();
				}
				ImageProcessOne imageProcessOne=new ImageProcessOne(filepath, "D://Done", "��ת", "jpg");
				try {
					imageProcessOne.spin(angel);
					label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath1))));
					panel.add(label_7,BorderLayout.CENTER);
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ͼƬ��ת�ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
		});

		mainpanel.add(button_2);




		Button button_3 = new Button("\u7F29\u653E");
		button_3.setFont(new Font("Dialog", Font.BOLD, 14));
		button_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {   //����
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(!isNumeric(textField_3.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���ȱ�������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(!isNumeric(textField_4.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�߶ȱ�������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				if(textField_3.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���Ȳ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_4.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�߶Ȳ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				String str1=textField_3.getText();
				String str2=textField_4.getText();	

				int width=Integer.parseInt(str1);
				int height=Integer.parseInt(str2);
				System.out.println(width+" "+height);
				if(width>20000||height>20000){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���ű��ʹ���", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(width<1||height<1){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���ű��ʹ�С��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				File donefile = new File("D:\\Done");
				if(!donefile.isFile()){
					donefile.mkdirs();
				}
				ImageProcessOne imageProcessOne=new ImageProcessOne(filepath, "D://Done", "����", "jpg");
				try {
					imageProcessOne.zoom(width, height);
					label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath2))));  
					panel.add(label_7);
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ͼƬ���ųɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
		});
		button_3.setActionCommand("\u65CB\u8F6C");
		button_3.setBounds(975, 207, 71, 23);
		mainpanel.add(button_3);

		Button button_4 = new Button("\u9A6C\u8D5B\u514B");
		button_4.setFont(new Font("Dialog", Font.BOLD, 14));
		button_4.addActionListener(new ActionListener() {   //������
			public void actionPerformed(ActionEvent e) {
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_5.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "������С����Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(!isNumeric(textField_5.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "������С��������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}


				String str3=textField_5.getText();

				int size= Integer.parseInt(str3);

				if(size>100){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "������С����", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				if(size==0){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "������С��������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				File donefile = new File("D:\\Done");
				if(!donefile.isFile()){
					donefile.mkdirs();
				}
				ImageProcessOne imageProcessOne=new ImageProcessOne(filepath, "D://Done", "������", "jpg");
				try {
					imageProcessOne.mosaic(size);
					label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath3))));  
					panel.add(label_7,BorderLayout.CENTER); 
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ͼƬ�����˳ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (Exception e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
		});
		button_4.setBounds(975, 265, 71, 23);
		mainpanel.add(button_4);

		Button button_5 = new Button("\u4E2D\u5FC3\u88C1\u526A");
		button_5.setFont(new Font("Dialog", Font.BOLD, 14));
		button_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {   //���Ĳü�
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_6.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���Ȳ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(!isNumeric(textField_6.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���ȴ�С��������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				String str4=textField_6.getText();
				int num=Integer.parseInt(str4);
				ImageProcessTwo imageProcessTwo=new ImageProcessTwo();
				try {
					File donefile = new File("D:\\Done");
					if(!donefile.isFile()){
						donefile.mkdirs();
					}
					imageProcessTwo.cutCenterImage(filepath, "D://Done/���Ĳü�.jpg", num, num);
					label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath4))));  
					panel.add(label_7,BorderLayout.CENTER);  
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ͼƬ���Ĳü��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
		});
		button_5.setActionCommand("\u65CB\u8F6C");
		button_5.setBounds(975, 323, 71, 23);
		mainpanel.add(button_5);

		Button button_6 = new Button("\u4E8C\u5206\u88C1\u526A");
		button_6.setFont(new Font("Dialog", Font.BOLD, 14));
		button_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {    //���ֲü�
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				ImageProcessTwo imageProcessTwo=new ImageProcessTwo();
				try {
					File donefile = new File("D:\\Done");
					if(!donefile.isFile()){
						donefile.mkdirs();
					}
					imageProcessTwo.cutHalfImage(filepath, "D://Done/���ֲü�.jpg");
					label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath5))));  
					panel.add(label_7,BorderLayout.CENTER);
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ͼƬ���ֲü��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				return;
			}
		});
		button_6.setActionCommand("\u65CB\u8F6C");
		button_6.setBounds(790, 379, 256, 23);
		mainpanel.add(button_6);

		Button button_7 = new Button("\u4EFB\u610F\u88C1\u526A");
		button_7.setFont(new Font("Dialog", Font.BOLD, 14));
		button_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {       //����ߴ�ü�
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_7.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���Ȳ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(textField_8.getText().equals("")){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�߶Ȳ���Ϊ�գ�", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				if(!isNumeric(textField_7.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "���ȱ�������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				if(!isNumeric(textField_8.getText())){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "�߶ȱ�������������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				String str5=textField_7.getText();
				String str6=textField_8.getText();
				int width=Integer.parseInt(str5);
				int height=Integer.parseInt(str6);
				System.out.println(width);
				System.out.println(height);
				ImageProcessTwo imageProcessTwo=new ImageProcessTwo();
				File donefile = new File("D:\\Done");
				if(!donefile.isFile()){
					donefile.mkdirs();
				}
				imageProcessTwo.cutRandomImage(filepath, "D://Done/����ü�.jpg", width, height);
				try {
					label_7.setIcon(new ImageIcon(ImageIO.read(new File(filepath6))));
					panel.add(label_7,BorderLayout.CENTER);
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "ͼƬ����ߴ�ü��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}    
				return;
			}
		});
		button_7.setActionCommand("\u65CB\u8F6C");
		button_7.setBounds(975, 435, 71, 23);
		mainpanel.add(button_7);

		textField_2 = new JTextField();
		textField_2.setFont(new Font("����", Font.BOLD, 14));
		textField_2.setToolTipText("");
		textField_2.setBounds(838, 150, 110, 22);
		mainpanel.add(textField_2);
		textField_2.setColumns(10);

		JLabel label = new JLabel("\u89D2\u5EA6");
		label.setForeground(Color.WHITE);
		label.setFont(new Font("����", Font.BOLD, 16));
		label.setBounds(790, 150, 46, 23);
		mainpanel.add(label);

		JLabel label_1 = new JLabel("\u5BBD");
		label_1.setForeground(Color.WHITE);
		label_1.setFont(new Font("����", Font.BOLD, 16));
		label_1.setBounds(790, 209, 20, 23);
		mainpanel.add(label_1);

		JLabel label_2 = new JLabel("\u9AD8");
		label_2.setForeground(Color.WHITE);
		label_2.setFont(new Font("����", Font.BOLD, 16));
		label_2.setBounds(876, 211, 20, 16);
		mainpanel.add(label_2);

		textField_3 = new JTextField();
		textField_3.setFont(new Font("����", Font.BOLD, 14));
		textField_3.setColumns(10);
		textField_3.setBounds(822, 208, 38, 22);
		mainpanel.add(textField_3);

		textField_4 = new JTextField();
		textField_4.setFont(new Font("����", Font.BOLD, 14));
		textField_4.setColumns(10);
		textField_4.setBounds(910, 208, 38, 22);
		mainpanel.add(textField_4);

		textField_5 = new JTextField();
		textField_5.setFont(new Font("����", Font.BOLD, 14));
		textField_5.setColumns(10);
		textField_5.setBounds(838, 266, 110, 22);
		mainpanel.add(textField_5);

		JLabel label_3 = new JLabel("\u9897\u7C92");
		label_3.setForeground(Color.WHITE);
		label_3.setFont(new Font("����", Font.BOLD, 16));
		label_3.setBounds(790, 268, 46, 20);
		mainpanel.add(label_3);

		textField_6 = new JTextField();
		textField_6.setFont(new Font("����", Font.BOLD, 14));
		textField_6.setColumns(10);
		textField_6.setBounds(838, 323, 108, 22);
		mainpanel.add(textField_6);

		textField_7 = new JTextField();
		textField_7.setFont(new Font("����", Font.BOLD, 14));
		textField_7.setColumns(10);
		textField_7.setBounds(822, 436, 38, 22);
		mainpanel.add(textField_7);

		textField_8 = new JTextField();
		textField_8.setFont(new Font("����", Font.BOLD, 14));
		textField_8.setColumns(10);
		textField_8.setBounds(910, 435, 38, 22);
		mainpanel.add(textField_8);

		JLabel label_4 = new JLabel("\u957F");
		label_4.setForeground(Color.WHITE);
		label_4.setFont(new Font("����", Font.BOLD, 16));
		label_4.setBounds(790, 325, 20, 16);
		mainpanel.add(label_4);

		JLabel label_5 = new JLabel("\u5BBD");
		label_5.setForeground(Color.WHITE);
		label_5.setFont(new Font("����", Font.BOLD, 16));
		label_5.setBounds(790, 439, 20, 16);
		mainpanel.add(label_5);

		JLabel label_6 = new JLabel("\u9AD8");
		label_6.setForeground(Color.WHITE);
		label_6.setFont(new Font("����", Font.BOLD, 16));
		label_6.setBounds(876, 439, 20, 16);
		mainpanel.add(label_6);

		textField_1 = new JTextField();
		textField_1.setFont(new Font("����", Font.BOLD, 14));
		textField_1.setText("\u539F\u56FE\u7247\u8DEF\u5F84");
		textField_1.setEditable(false);
		textField_1.setBounds(788, 91, 160, 22);
		mainpanel.add(textField_1);
		textField_1.setColumns(10);

		Button button_8 = new Button("\u6C34\u5370\u52A0\u5BC6");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(watermarkpath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "��ѡ��ˮӡͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				JOptionPane jOptionPane=new JOptionPane();


				AddWatermark addWatermark =new AddWatermark();
				File donefile = new File("D:\\Done");
				if(!donefile.isFile()){
					donefile.mkdirs();
				}
				if(addWatermark.run(filepath, watermarkpath, "D://Done/���ܳɹ�.bmp")==-1){
					jOptionPane.showMessageDialog(null, "ˮӡͼƬ�ֱ��ʹ�С��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				if(addWatermark.run(filepath, watermarkpath, "D://Done/���ܳɹ�.bmp")==-2){
					jOptionPane.showMessageDialog(null, "������ԭͼƬ��ˮӡͼƬ�ֱ��ʱ�������", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}
				//addWatermark.run(filepath, watermarkpath, "D://Done/���ܳɹ�.bmp");
				try {
					label_7.setIcon(new ImageIcon(ImageIO.read(new File("D://Done/���ܳɹ�.bmp"))));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				panel.add(label_7,BorderLayout.CENTER);
				jOptionPane.showMessageDialog(null, "ͼƬ����ˮӡ���ܳɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);

			}
		});
		button_8.setFont(new Font("Dialog", Font.BOLD, 14));
		button_8.setActionCommand("\u65CB\u8F6C");
		button_8.setBounds(792, 606, 256, 23);
		mainpanel.add(button_8);



		Button button_11 = new Button("\u6C34\u5370\u89E3\u5BC6");
		button_11.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(filepath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "����ѡ��ԭͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				if(encpath==null){
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "��ѡ�������ͼƬ��", "����", JOptionPane.ERROR_MESSAGE);
					return;
				}

				ExtractWatermark extractWatermark=new ExtractWatermark();
				File donefile = new File("D:\\Done");
				if(!donefile.isFile()){
					donefile.mkdirs();
				}
				extractWatermark.run(encpath, filepath, "D://Done/���ܳɹ�.bmp", 30, 30);

				try {
					label_7.setIcon(new ImageIcon(ImageIO.read(new File("D://Done/���ܳɹ�.bmp"))));
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				panel.add(label_7,BorderLayout.CENTER);

				JOptionPane jOptionPane=new JOptionPane();
				jOptionPane.showMessageDialog(null, "ͼƬ����ˮӡ���ܳɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				return;
			}
		});
		button_11.setFont(new Font("����", Font.BOLD, 14));
		button_11.setActionCommand("\u65CB\u8F6C");
		button_11.setBounds(792, 714, 256, 23);
		mainpanel.add(button_11);

		textField_9 = new JTextField();
		textField_9.setText("\u6C34\u5370\u56FE\u7247\u8DEF\u5F84");
		textField_9.setFont(new Font("����", Font.BOLD, 14));
		textField_9.setEditable(false);
		textField_9.setColumns(10);
		textField_9.setBounds(792, 548, 160, 22);
		mainpanel.add(textField_9);

		Button button_9 = new Button("\u9009\u62E9\u6587\u4EF6");
		button_9.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser jFileChooser = new JFileChooser();
				File file = null;
				int retureval = jFileChooser.showOpenDialog(null);
				if(retureval == JFileChooser.APPROVE_OPTION){
					file = jFileChooser.getSelectedFile();
					watermarkpath = file.getAbsolutePath();
					textField_9.setText(watermarkpath);
					JOptionPane jOptionPane=new JOptionPane();
					try {
						label_7.setIcon(new ImageIcon(ImageIO.read(new File(watermarkpath))));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					panel.add(label_7,BorderLayout.CENTER);
					jOptionPane.showMessageDialog(null, "ˮӡͼƬѡ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
				}
				else if(retureval==JFileChooser.CANCEL_OPTION){
					return;
				}

			}
		});
		button_9.setFont(new Font("Dialog", Font.BOLD, 14));
		button_9.setActionCommand("\u65CB\u8F6C");
		button_9.setBounds(977, 547, 71, 23);
		mainpanel.add(button_9);

		textField_10 = new JTextField();
		textField_10.setText("\u5F85\u89E3\u5BC6\u56FE\u7247\u8DEF\u5F84");
		textField_10.setFont(new Font("����", Font.BOLD, 14));
		textField_10.setEditable(false);
		textField_10.setColumns(10);
		textField_10.setBounds(790, 662, 160, 22);
		mainpanel.add(textField_10);

		Button button_10 = new Button("\u9009\u62E9\u6587\u4EF6");
		button_10.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JFileChooser jFileChooser = new JFileChooser();
				File file = null;
				int retureval = jFileChooser.showOpenDialog(null);
				if(retureval == JFileChooser.APPROVE_OPTION){
					file = jFileChooser.getSelectedFile();
					encpath = file.getAbsolutePath();
					textField_10.setText(encpath);
					JOptionPane jOptionPane=new JOptionPane();
					jOptionPane.showMessageDialog(null, "������ͼƬѡ��ɹ���", "��ʾ", JOptionPane.INFORMATION_MESSAGE);
					try {
						label_7.setIcon(new ImageIcon(ImageIO.read(new File(encpath))));
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					panel.add(label_7,BorderLayout.CENTER);
				}
				else if(retureval==JFileChooser.CANCEL_OPTION){
					return;
				}
			}
		});
		button_10.setFont(new Font("����", Font.BOLD, 14));
		button_10.setActionCommand("\u65CB\u8F6C");
		button_10.setBounds(977, 661, 71, 23);
		mainpanel.add(button_10);

		JPanel panel_1 = new JPanel();
		panel_1.setBackground(Color.DARK_GRAY);
		panel_1.setBounds(776, 21, 285, 455);
		mainpanel.add(panel_1);
		panel_1.setLayout(null);

		JLabel label_8 = new JLabel("\u5E38    \u89C4    \u64CD    \u4F5C");
		label_8.setBounds(0, 12, 285, 33);
		label_8.setFont(new Font("΢���ź�", Font.BOLD, 24));
		label_8.setHorizontalAlignment(SwingConstants.CENTER);
		label_8.setForeground(Color.WHITE);
		panel_1.add(label_8);

		JPanel panel_2 = new JPanel();
		panel_2.setBackground(Color.DARK_GRAY);
		panel_2.setBounds(776, 487, 285, 265);
		mainpanel.add(panel_2);
		panel_2.setLayout(null);

		JLabel label_9 = new JLabel("\u52A0   \u5BC6   &   \u89E3   \u5BC6");
		label_9.setHorizontalAlignment(SwingConstants.CENTER);
		label_9.setForeground(Color.WHITE);
		label_9.setFont(new Font("΢���ź�", Font.BOLD, 24));
		label_9.setBounds(0, 9, 285, 33);
		panel_2.add(label_9);





		main.setBackground(Color.WHITE);
		main.setSize(1091, 800);
		main.setVisible(true);



	}
}