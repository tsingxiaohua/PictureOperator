package MainProcess;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;

import javax.imageio.ImageIO;
import javax.imageio.ImageReadParam;
import javax.imageio.ImageReader;
import javax.imageio.stream.ImageInputStream;

public class ImageProcessTwo {  
	/* 
	 * ���ݳߴ�ͼƬ���вü� 
	 */  
	public static void cutCenterImage(String src,String dest,int w,int h) throws IOException{   
		Iterator iterator = ImageIO.getImageReadersByFormatName("jpg");   
		ImageReader reader = (ImageReader)iterator.next();   
		InputStream in=new FileInputStream(src);  
		ImageInputStream iis = ImageIO.createImageInputStream(in);   
		reader.setInput(iis, true);   
		ImageReadParam param = reader.getDefaultReadParam();   
		int imageIndex = 0;   
		Rectangle rect = new Rectangle((reader.getWidth(imageIndex)-w)/2, (reader.getHeight(imageIndex)-h)/2, w, h);    
		param.setSourceRegion(rect);   
		BufferedImage bi = reader.read(0,param);     
		ImageIO.write(bi, "jpg", new File(dest));             
		System.out.println("ͼƬ���вü���ɣ�");
	}  
	/* 
	 * ͼƬ�ü�����֮һ 
	 */  
	public static void cutHalfImage(String src,String dest) throws IOException{   
		Iterator iterator = ImageIO.getImageReadersByFormatName("jpg");   
		ImageReader reader = (ImageReader)iterator.next();   
		InputStream in=new FileInputStream(src);  
		ImageInputStream iis = ImageIO.createImageInputStream(in);   
		reader.setInput(iis, true);   
		ImageReadParam param = reader.getDefaultReadParam();   
		int imageIndex = 0;   
		int width = reader.getWidth(imageIndex)/2;   
		int height = reader.getHeight(imageIndex)/2;   
		Rectangle rect = new Rectangle(width/2, height/2, width, height);   
		param.setSourceRegion(rect);   
		BufferedImage bi = reader.read(0,param);     
		ImageIO.write(bi, "jpg", new File(dest)); 
		System.out.println("ͼƬ����֮һ�ü���ɣ�");
	}  
	
	
    /** 
     * ͼƬ����ü� 
     * @param srcImageFile ͼƬ�ü���ַ 
     * @param result ͼƬ����ļ��� 
     * @param destWidth ͼƬ�ü����� 
     * @param destHeight ͼƬ�ü��߶� 
     */  
    public  static void cutRandomImage(String srcImageFile, String result,  
            int destWidth, int destHeight) {  
        try {  
            Iterator iterator = ImageIO.getImageReadersByFormatName("JPEG");/*PNG,BMP*/     
            ImageReader reader = (ImageReader)iterator.next();/*��ȡͼƬ�ߴ�*/  
            InputStream inputStream = new FileInputStream(srcImageFile);    
            ImageInputStream iis = ImageIO.createImageInputStream(inputStream);     
            reader.setInput(iis, true);     
            ImageReadParam param = reader.getDefaultReadParam();     
            Rectangle rectangle = new Rectangle(0,0, destWidth, destHeight);/*ָ����ȡ��Χ*/      
            param.setSourceRegion(rectangle);     
            BufferedImage bi = reader.read(0,param);   
            ImageIO.write(bi, "JPEG", new File(result));  
            System.out.println("ͼƬ����ü���ɣ�");
        } catch (Exception e) {
            System.out.println("ͼƬ�ü������쳣:");
            e.printStackTrace();
        }  
    }  
	
	
	/* 
	 * ͼƬ�ü�ͨ�ýӿ� 
	 */  

	public static void cutImage(String src,String dest,int x,int y,int w,int h) throws IOException{   
		Iterator iterator = ImageIO.getImageReadersByFormatName("jpg");   
		ImageReader reader = (ImageReader)iterator.next();   
		InputStream in=new FileInputStream(src);  
		ImageInputStream iis = ImageIO.createImageInputStream(in);   
		reader.setInput(iis, true);   
		ImageReadParam param = reader.getDefaultReadParam();   
		Rectangle rect = new Rectangle(x, y, w,h);    
		param.setSourceRegion(rect);   
		BufferedImage bi = reader.read(0,param);     
		ImageIO.write(bi, "jpg", new File(dest));             
	}   
	
}  